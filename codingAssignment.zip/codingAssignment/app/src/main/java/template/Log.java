package template;
/**
 * The Log class is used in the LogList class and represents a JSON object read in 
 * from a text file. 
 */
public class Log {
    private String id;
    private String state;
    private String type;
    private String host;
    private long timestamp;

    public String getId() {
        return id;
    }
    public String getType() {
        return type;
    }
    public long getTimestamp() {
        return this.timestamp;
    }
    public String getState(){
        return this.state;
    }
    public String getHost(){
        return this.host;
    }
}
