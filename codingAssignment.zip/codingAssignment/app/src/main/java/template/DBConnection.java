package template;
import java.sql.*;
/**
 * The DBConnection class is responsible for all database connections.
 */
class DBConnection{
    private String tableName = "LOGFILES";
    private String username;
    private String url;
    private String password;
    public DBConnection(String url, String username, String password){
        this.url = url;
        this.username = username;
        this.password = password;
    }
    /**
     * The createTable function creates a connection to the database and executes a sql
     * querry to create a table with the name of the tableName variable. If there already
     * exists a simmilar table it won't create a new one.
     */
    public void createTable(){
        Connection conn = null;
        try{
            conn = DriverManager.getConnection(this.url, this.username, this.password);
            boolean tableExists = tableExists(conn, "LOGFILES");
            if(!tableExists){
                Statement stmt = conn.createStatement();
                String sql = "CREATE TABLE " + this.tableName +
                    "(EVENT_ID VARCHAR(255) NOT NULL PRIMARY KEY, " + 
                    " EVENT_DURATION INT, " + 
                    " TYPE VARCHAR(255), " + 
                    " HOST VARCHAR(255)," +
                    " ALERT BOOLEAN) "; 
                stmt.executeUpdate(sql);
            }
        } catch (SQLException e) {
            throw new Error("Problem", e);
        } finally {
            try{
                if(conn != null){
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }
    /**
     * The private tableExists function is used to check if a table with the name saved
     * in the tableName variable already exists.
     * @param connection The connection variable holds the connection to the database.
     * @param tableName The table Name variable is used to check if the table already exists.
     * @return The return boolean indicates if the table already exists or not.
     * @throws SQLException 
     */
    private boolean tableExists(Connection connection, String tableName) throws SQLException {
        DatabaseMetaData meta = connection.getMetaData();
        ResultSet resultSet = meta.getTables(null, null, tableName, new String[] {"TABLE"});
        return resultSet.next();
    }
    /**
     * The sendData function creates a database connection and executes a sql statement to
     * save the data from the list Variable to the database.
     * @param list The list variable holds the data, which needs to get saved to the database.
     */
    public void sendData(LogList list){
        Connection conn = null;
        try{
            conn = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
        } catch (SQLException e){
            throw new Error("Problem", e);
        }
        try{
            Statement stmt = conn.createStatement();
            String sql = "INSERT INTO " + this.tableName + 
                        " (EVENT_ID, EVENT_DURATION, TYPE, HOST, ALERT)\n" + 
                        "VALUES ('" +list.getId()+ "', '" +list.getDuration()+ "', '" +list.getType()+ 
                        "', '" +list.getHost()+ "', '" +list.getAlert()+ "');";
            stmt.executeUpdate(sql);
            System.out.println("Data sent");
        } catch (SQLException e) {
            System.out.println("Event_id "+list.getId()+" already exists.");
        } finally {
            try{
                if(conn != null){
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }
}