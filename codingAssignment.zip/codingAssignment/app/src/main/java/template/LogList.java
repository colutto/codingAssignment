package template;
/**
 * The LogList class holds two Log class objects which have the same event id.
 * Moreover it performs the neccessary calculation of the duration time, which is
 * used to determ the output of the alert object. Additionally the function 
 * logsAvailable is used to see if the Log objects aren't null.
 */
public class LogList {
    private Log firstLog;
    private Log secondLog;

    public void addFirstLog(Log firstLog) {
        this.firstLog = firstLog;
    }
    public void addSecondLog(Log secondLog) {
        this.secondLog = secondLog;
    }
    public boolean getAlert() {
        long duration = Math.abs(this.firstLog.getTimestamp()-this.secondLog.getTimestamp());
        if(duration>5){
            return false;
        } else return true;
    }
    public long getDuration(){
        long duration = Math.abs(this.firstLog.getTimestamp()-this.secondLog.getTimestamp());
        return duration;
    }
    public String getId(){
        return this.firstLog.getId();
    }
    public String getType(){
        return this.firstLog.getType();
    }
    public String getHost(){
        return this.firstLog.getHost();
    }
    public boolean logsAvailable(){
        if(this.firstLog!=null && this.secondLog!=null){
            return true;
        } else return false;
    }
}
